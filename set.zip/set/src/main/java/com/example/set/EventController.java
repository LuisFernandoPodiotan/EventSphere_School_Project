package com.example.set;

import com.example.set.model.Event;
import com.example.set.model.User;
import com.example.set.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "http://localhost:5500")  // Adjust to your frontend server
public class EventController {
    @Autowired
    private EventService eventService;

    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/search")
    public List<Event> searchEvents(@RequestParam String query) {
        return eventService.searchEvents(query);
    }

    @GetMapping
    public ResponseEntity<List<Event>> getAllEvents() {
        try {
            List<Event> events = eventService.getAllEvents();
            return ResponseEntity.ok(events);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @PostMapping("/{eventId}/join")
    public ResponseEntity<?> joinEvent(@PathVariable Long eventId, @RequestParam String username) {
        try {
            boolean joined = eventService.joinEvent(eventId, username);
            if (joined) {
                return ResponseEntity.ok("Successfully joined the event");
            } else {
                return ResponseEntity.badRequest().body("Cannot join event");
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(e.getMessage());
        }
    }

    @PostMapping
    public ResponseEntity<Event> createEvent(@RequestBody Event event, @RequestParam String username) {
        try {
            Event createdEvent = eventService.createEvent(event, username);
            return ResponseEntity.ok(createdEvent);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(null);
        }
    }

    @GetMapping("/{eventId}/participants")
    public ResponseEntity<Set<User>> getParticipants(@PathVariable Long eventId) {
        try {
            Set<User> participants = eventService.getParticipants(eventId);
            return ResponseEntity.ok(participants);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }

    @GetMapping("/creator/{userId}")
    public ResponseEntity<List<Event>> getEventsByCreator(@PathVariable Long userId) {
        try {
            List<Event> events = eventService.getEventsByCreator(userId);
            return ResponseEntity.ok(events);
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body(null);
        }
    }
}


