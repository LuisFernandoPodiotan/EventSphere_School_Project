package com.example.set.repository;

import com.example.set.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventRepositoru extends JpaRepository<Event, Long> {
    // Custom query methods
    List<Event> findByOrganizerName(String organizerName);
    List<Event> findByLocation(String location);
    List<Event> findByTitleContaining(String keyword);
    List<Event> findByTitleContainingIgnoreCase(String query);

    // Check if an event with the same title exists
    boolean existsByTitle(String title);

    // Retrieve events created by a specific user
    @Query("SELECT e FROM Event e WHERE e.createdBy.id = :userId")
    List<Event> findEventsByCreator(@Param("userId") Long userId);

    // Retrieve participants of a specific event
    @Query("SELECT e.participants FROM Event e WHERE e.id = :eventId")
    List<Object> findParticipantsByEventId(@Param("eventId") Long eventId);
}

