package com.example.set;

public @interface AuthenticationPrincipal {

}
