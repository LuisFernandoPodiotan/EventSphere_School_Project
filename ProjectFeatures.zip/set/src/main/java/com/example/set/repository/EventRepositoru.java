package com.example.set.repository;


import com.example.set.model.Event;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface EventRepositoru extends JpaRepository<Event, Long> {
    // Custom query methods
    List<Event> findByOrganizerName(String organizerName);
    List<Event> findByLocation(String location);
    List<Event> findByTitleContaining(String keyword);
	List<Event> findByTitleContainingIgnoreCase(String query);
}

