package com.example.set.service;



import com.example.set.model.Event;
import com.example.set.repository.EventRepositoru;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
public class EventService {
    @Autowired
    private EventRepositoru eventRepository;

    @Transactional
    public Event createEvent(Event event) {
        // Validate event before saving
        if (event.getMaxParticipants() <= 0) {
            throw new IllegalArgumentException("Max participants must be greater than 0");
        }
        return eventRepository.save(event);
    }



    @Transactional
    public boolean joinEvent(Long eventId) {
        Event event = eventRepository.findById(eventId)
            .orElseThrow(() -> new RuntimeException("Event not found"));
        
        if (event.getCurrentParticipants() >= event.getMaxParticipants()) {
            throw new RuntimeException("Event is full");
        }
        
        event.setCurrentParticipants(event.getCurrentParticipants() + 1);
        eventRepository.save(event);
        return true;
    }



	public List<Event> getAllEvents() {
		return eventRepository.findAll();
	}

	public EventService(EventRepositoru eventRepository) {
        this.eventRepository = eventRepository;
    }
	
	 public List<Event> searchEvents(String query) {
	        return eventRepository.findByTitleContainingIgnoreCase(query);
	    }

	
}

