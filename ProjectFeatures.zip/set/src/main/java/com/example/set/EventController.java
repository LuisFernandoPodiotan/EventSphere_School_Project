package com.example.set;

import com.example.set.model.Event;
import com.example.set.service.EventService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/events")
@CrossOrigin(origins = "http://localhost:5500")  // Adjust to your frontend server
public class EventController {
    @Autowired
    private EventService eventService;
    
    public EventController(EventService eventService) {
        this.eventService = eventService;
    }

    @GetMapping("/search")
    public List<Event> searchEvents(@RequestParam String query) {
        return eventService.searchEvents(query);
    }
    
    @GetMapping
    public List<Event> getAllEvents() {
        return eventService.getAllEvents();
    }
    
    @PostMapping("/{eventId}/join")
    public ResponseEntity<?> joinEvent(@PathVariable Long eventId) {
        try {
            boolean joined = eventService.joinEvent(eventId);
            if (joined) {
                return ResponseEntity.ok("Successfully joined the event");
            } else {
                return ResponseEntity.badRequest().body("Cannot join event");
            }
        } catch (Exception e) {
            return ResponseEntity.internalServerError().body("Error joining event");
        }
    }


    @PostMapping
    public ResponseEntity<Event> createEvent(@RequestBody Event event) {
        Event createdEvent = eventService.createEvent(event);
        return ResponseEntity.ok(createdEvent);
    }

   

}

 
