package com.example.set.service;

import com.example.set.model.Event;
import com.example.set.model.User;
import com.example.set.repository.EventRepositoru;
import com.example.set.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Set;

@Service
public class EventService {
    @Autowired
    private EventRepositoru eventRepository;

    @Autowired
    private UserRepository userRepository;

    public EventService(EventRepositoru eventRepository, UserRepository userRepository) {
        this.eventRepository = eventRepository;
        this.userRepository = userRepository;
    }
    @Transactional
    public Event createEvent(Event event, String username) {
        if (event.getStartTime().isAfter(event.getEndTime())) {
            throw new IllegalArgumentException("Start time must be before end time");
        }
        if (event.getMaxParticipants() <= 0) {
            throw new IllegalArgumentException("Max participants must be greater than 0");
        }
        if (eventRepository.existsByTitle(event.getTitle())) {
            throw new IllegalArgumentException("An event with this title already exists");
        }
    
        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found");
        }
        event.setCreatedBy(user);
    
        return eventRepository.save(event);
    }

    @Transactional
    public boolean joinEvent(Long eventId, String username) {
        Event event = eventRepository.findById(eventId)
            .orElseThrow(() -> new RuntimeException("Event not found"));

        User user = userRepository.findByUsername(username);
        if (user == null) {
            throw new RuntimeException("User not found");
        }

        // Check if the user has already joined the event
        if (event.getParticipants().contains(user)) {
            throw new RuntimeException("User has already joined the event");
        }

        // Check if the event is full
        if (event.getCurrentParticipants() >= event.getMaxParticipants()) {
            throw new RuntimeException("Event is full");
        }

        // Add the user to the event's participants
        event.getParticipants().add(user);
        event.setCurrentParticipants(event.getCurrentParticipants() + 1);
        eventRepository.save(event);

        return true;
    }

    public List<Event> getAllEvents() {
        return eventRepository.findAll();
    }

    public List<Event> searchEvents(String query) {
        return eventRepository.findByTitleContainingIgnoreCase(query);
    }

    public List<Event> getEventsByCreator(Long userId) {
        return eventRepository.findEventsByCreator(userId);
    }

    public Set<User> getParticipants(Long eventId) {
        Event event = eventRepository.findById(eventId)
            .orElseThrow(() -> new RuntimeException("Event not found"));
        return event.getParticipants();
    }
}

